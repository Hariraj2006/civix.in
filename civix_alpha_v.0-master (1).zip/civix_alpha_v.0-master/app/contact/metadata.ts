import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Us - Civix",
  description: "Get in touch with the Civix team for support or inquiries",
}; 